# 💖 Sevgililer Günü Oyunu - Web Versiyonu

## Web'de Çalıştırma

### Yöntem 1: Pygbag ile Lokal Test

1. Pygbag'i yükleyin:
```bash
pip install pygbag
```

2. Oyunu web sunucusunda çalıştırın:
```bash
pygbag valentine_game.py
```

3. Tarayıcınızda açın:
```
http://localhost:8000
```

### Yöntem 2: Manuel HTML Sunucusu

1. Python HTTP sunucusu başlatın:
```bash
python -m http.server 8000
```

2. Tarayıcıda açın:
```
http://localhost:8000/index.html
```

## Web'e Yükleme (GitHub Pages, Netlify, vb.)

### GitHub Pages için:

1. Repository'nizi oluşturun
2. Tüm dosyaları push edin
3. Settings > Pages > Source: main branch
4. `index.html` otomatik olarak servis edilecek

### Netlify için:

1. Netlify'a giriş yapın
2. "New site from Git" veya drag & drop ile yükleyin
3. Build settings: Yok (statik site)
4. Publish directory: `/` (root)

## Dosya Yapısı

```
.
├── index.html              # Ana web sayfası
├── main.py                 # Web için giriş noktası
├── valentine_game.py       # Ana oyun kodu
├── constants.py            # Sabitler
├── entities.py             # Oyun objeleri
├── levels.py               # Bölümler
├── game_screens.py         # Ekranlar
├── backgrounds.py          # Arka planlar
├── requirements.txt        # Python bağımlılıkları
└── *.png                   # Görseller
```

## Önemli Notlar

- Pygbag, Pygame oyunlarını WebAssembly'ye çevirir
- Tüm görseller (.png) ve ses dosyaları otomatik olarak paketlenir
- Oyun 800x600 çözünürlükte çalışır
- Mobil cihazlarda da çalışır (dokunmatik kontroller otomatik)

## Sorun Giderme

### Oyun yüklenmiyor:
- Tarayıcı konsolunu kontrol edin (F12)
- CORS hatası varsa lokal sunucu kullanın
- Tüm .png dosyalarının aynı klasörde olduğundan emin olun

### Performans sorunları:
- FPS'i düşürün (constants.py'de FPS = 30)
- Görselleri optimize edin (boyutları küçültün)

## Tarayıcı Desteği

✅ Chrome/Edge (önerilen)
✅ Firefox
✅ Safari
⚠️ Eski tarayıcılar (WebAssembly desteği gerekli)
