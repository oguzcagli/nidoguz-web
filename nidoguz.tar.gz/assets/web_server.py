#!/usr/bin/env python3
"""
Basit HTTP sunucu - Oyunu test etmek için
"""
import http.server
import socketserver
import webbrowser
import os

PORT = 8000

class MyHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        # CORS başlıkları ekle
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Cross-Origin-Embedder-Policy', 'require-corp')
        self.send_header('Cross-Origin-Opener-Policy', 'same-origin')
        super().end_headers()

def start_server():
    """Sunucuyu başlat"""
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    with socketserver.TCPServer(("", PORT), MyHTTPRequestHandler) as httpd:
        print("=" * 50)
        print("  💖 Sevgililer Günü Oyunu - Web Sunucu 💖")
        print("=" * 50)
        print(f"\n✓ Sunucu başlatıldı: http://localhost:{PORT}")
        print(f"✓ Tarayıcınızda açılıyor...")
        print(f"\n📁 Dosyalar: {os.getcwd()}")
        print(f"\n⚠️  Kapatmak için Ctrl+C basın\n")
        
        # Tarayıcıyı aç
        webbrowser.open(f'http://localhost:{PORT}')
        
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n\n✓ Sunucu kapatıldı.")

if __name__ == "__main__":
    start_server()
