#!/usr/bin/env python3
"""Web versiyonunu başlatır - basit ve hızlı"""

import subprocess
import sys
import webbrowser
import time
import os

print("🎮 Valentine Oyunu - Web Versiyonu")
print("=" * 50)

# Web klasörüne git
os.chdir("web")

print("\n🔨 Build ediliyor...")
result = subprocess.run([sys.executable, "-m", "pygbag", "--build", "."], 
                       capture_output=True, text=True)

if result.returncode != 0:
    print("❌ Build hatası!")
    print(result.stderr)
    input("\nDevam etmek için Enter'a basın...")
    sys.exit(1)

print("✅ Build tamamlandı!")

print("\n🚀 Sunucu başlatılıyor...")
print("📱 Tarayıcıda açılacak: http://localhost:8000")
print("⏹️  Durdurmak için Ctrl+C")
print("-" * 50)

# Tarayıcıyı 2 saniye sonra aç
def open_browser():
    time.sleep(2)
    webbrowser.open("http://localhost:8000")

import threading
threading.Thread(target=open_browser, daemon=True).start()

# Sunucuyu başlat
try:
    subprocess.run([sys.executable, "-m", "http.server", "8000", 
                   "--directory", "build/web"])
except KeyboardInterrupt:
    print("\n\n✅ Sunucu durduruldu!")
