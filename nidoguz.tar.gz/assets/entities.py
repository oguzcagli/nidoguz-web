import pygame
from constants import *

class Coin:
    """Toplanabilir coin/kalp"""
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.rect = pygame.Rect(x + 8, y + 8, 24, 24)
        self.collected = False
    
    def draw(self, screen):
        """Çiz"""
        if not self.collected:
            # Kalp çiz
            pygame.draw.circle(screen, RED, (int(self.x + 12), int(self.y + 12)), 6)
            pygame.draw.circle(screen, RED, (int(self.x + 20), int(self.y + 12)), 6)
            points = [(self.x + 8, self.y + 16), (self.x + 16, self.y + 26), (self.x + 24, self.y + 16)]
            pygame.draw.polygon(screen, RED, points)


class Player:
    """Oyuncu karakteri - Platformer"""
    def __init__(self, x, y, idle_sprite, walk_sprite, walk_other_sprite=None, idle_back_sprite=None, walk_back_sprite=None, walk_other_back_sprite=None):
        self.x = x
        self.y = y
        self.velocity_x = 0
        self.velocity_y = 0
        self.speed = 5
        self.on_ground = False
        self.rect = pygame.Rect(x, y, PLAYER_WIDTH, PLAYER_HEIGHT)
        
        # Sağa bakan sprite'lar (normal)
        raw_idle = pygame.image.load(idle_sprite).convert_alpha()
        self.idle_image = pygame.transform.scale(raw_idle, (PLAYER_WIDTH, PLAYER_HEIGHT))
        
        raw_walk = pygame.image.load(walk_sprite).convert_alpha()
        self.walk_image = pygame.transform.scale(raw_walk, (PLAYER_WIDTH, PLAYER_HEIGHT))
        
        # İkinci yürüme sprite'ı varsa yükle (animasyon için)
        if walk_other_sprite:
            try:
                raw_walk_other = pygame.image.load(walk_other_sprite).convert_alpha()
                self.walk_other_image = pygame.transform.scale(raw_walk_other, (PLAYER_WIDTH, PLAYER_HEIGHT))
            except:
                self.walk_other_image = None
        else:
            self.walk_other_image = None
        
        # Sola bakan sprite'lar (back)
        if idle_back_sprite:
            try:
                raw_idle_back = pygame.image.load(idle_back_sprite).convert_alpha()
                self.idle_back_image = pygame.transform.scale(raw_idle_back, (PLAYER_WIDTH, PLAYER_HEIGHT))
            except:
                self.idle_back_image = None
        else:
            self.idle_back_image = None
        
        if walk_back_sprite:
            try:
                raw_walk_back = pygame.image.load(walk_back_sprite).convert_alpha()
                self.walk_back_image = pygame.transform.scale(raw_walk_back, (PLAYER_WIDTH, PLAYER_HEIGHT))
            except:
                self.walk_back_image = None
        else:
            self.walk_back_image = None
        
        if walk_other_back_sprite:
            try:
                raw_walk_other_back = pygame.image.load(walk_other_back_sprite).convert_alpha()
                self.walk_other_back_image = pygame.transform.scale(raw_walk_other_back, (PLAYER_WIDTH, PLAYER_HEIGHT))
            except:
                self.walk_other_back_image = None
        else:
            self.walk_other_back_image = None
        
        self.image = self.idle_image
        
        # Oyun değişkenleri
        self.health = 3
        self.max_health = 3
        self.score = 0
        self.moving = False
        self.facing_right = True  # Hangi yöne bakıyor
        self.enemies_killed = 0  # Öldürülen düşman sayısı
        
        # Animasyon değişkenleri
        self.animation_frame = 0
        self.animation_counter = 0
        self.animation_speed = 8  # Her 8 frame'de bir değiş
    
    def jump(self):
        """Zıpla - daha hassas kontrol"""
        # Yerdeyse veya çok az havadaysa zıpla
        if self.on_ground or abs(self.velocity_y) < 2:
            self.velocity_y = JUMP_STRENGTH
            self.on_ground = False
            return True
        return False

    def move(self, dx, game_map):
        """Yatay hareket"""
        self.moving = (dx != 0)
        self.velocity_x = dx * self.speed
        
        # Yön güncelle
        if dx > 0:
            self.facing_right = True
        elif dx < 0:
            self.facing_right = False
    
    def update(self, game_map):
        """Fizik ve hareket güncelle"""
        # Yerçekimi uygula
        self.velocity_y += GRAVITY
        
        # Maksimum düşme hızı
        if self.velocity_y > 20:
            self.velocity_y = 20
        
        # Yatay hareket
        self.x += self.velocity_x
        self.rect.x = self.x
        self.check_collision_x(game_map)
        
        # Dikey hareket
        self.y += self.velocity_y
        self.rect.y = self.y
        self.on_ground = False
        self.check_collision_y(game_map)
        
        # Sprite ve animasyon güncelle
        if self.moving:
            # Yürüme animasyonu
            self.animation_counter += 1
            if self.animation_counter >= self.animation_speed:
                self.animation_counter = 0
                # Frame değiştir: 1 <-> 2 (walk <-> walk_other)
                if self.animation_frame == 1:
                    self.animation_frame = 2
                else:
                    self.animation_frame = 1
            
            # Yöne ve frame'e göre sprite seç
            if self.facing_right:
                # Sağa gidiyor
                if self.walk_other_image and self.animation_frame == 2:
                    self.image = self.walk_other_image
                else:
                    self.image = self.walk_image
            else:
                # Sola gidiyor (back sprite'lar)
                if self.walk_other_back_image and self.animation_frame == 2:
                    self.image = self.walk_other_back_image
                elif self.walk_back_image:
                    self.image = self.walk_back_image
                else:
                    # Back sprite yoksa normal sprite kullan
                    if self.walk_other_image and self.animation_frame == 2:
                        self.image = self.walk_other_image
                    else:
                        self.image = self.walk_image
        else:
            # Duruyorsa idle sprite ve frame'i sıfırla
            if self.facing_right:
                self.image = self.idle_image
            else:
                # Sola bakıyorsa idle_back kullan
                if self.idle_back_image:
                    self.image = self.idle_back_image
                else:
                    self.image = self.idle_image
            self.animation_frame = 0
            self.animation_counter = 0
        
        # Ekran dışına çıkma kontrolü
        if self.y > SCREEN_HEIGHT:
            self.health = 0
    
    def check_collision_x(self, game_map):
        """Yatay çarpışma kontrolü"""
        for row_idx, row in enumerate(game_map):
            for col_idx, tile in enumerate(row):
                if tile == 1:  # Platform
                    tile_rect = pygame.Rect(col_idx * TILE_SIZE, row_idx * TILE_SIZE, TILE_SIZE, TILE_SIZE)
                    if self.rect.colliderect(tile_rect):
                        if self.velocity_x > 0:  # Sağa gidiyor
                            self.rect.right = tile_rect.left
                        elif self.velocity_x < 0:  # Sola gidiyor
                            self.rect.left = tile_rect.right
                        self.x = self.rect.x

    def check_collision_y(self, game_map):
        """Dikey çarpışma kontrolü"""
        for row_idx, row in enumerate(game_map):
            for col_idx, tile in enumerate(row):
                if tile == 1:  # Platform
                    tile_rect = pygame.Rect(col_idx * TILE_SIZE, row_idx * TILE_SIZE, TILE_SIZE, TILE_SIZE)
                    if self.rect.colliderect(tile_rect):
                        if self.velocity_y > 0:  # Aşağı düşüyor
                            self.rect.bottom = tile_rect.top
                            self.velocity_y = 0
                            self.on_ground = True
                        elif self.velocity_y < 0:  # Yukarı zıplıyor
                            self.rect.top = tile_rect.bottom
                            self.velocity_y = 0
                        self.y = self.rect.y
    
    def draw(self, screen):
        """Çiz"""
        screen.blit(self.image, (self.x, self.y))
    
    def take_damage(self):
        """Hasar al"""
        self.health -= 1
    
    def add_score(self, points):
        """Skor ekle"""
        self.score += points
    
    def enemy_killed(self):
        """Düşman öldürüldü - her 5 düşmanda can ekle"""
        self.enemies_killed += 1
        
        # Her 5 düşmanda bir can ekle (eğer can full değilse)
        if self.enemies_killed % 5 == 0 and self.health < self.max_health:
            self.health += 1
            print(f"🎉 Bonus can! Toplam can: {self.health}")
    
    def reset_for_level(self, game_map, level_index=0):
        """Bölüm için sıfırla - zemini otomatik bul"""
        self.x = TILE_SIZE
        
        # Zemini bul (tile 1 olan ilk satır)
        ground_row = 11  # Varsayılan
        for row_idx, row in enumerate(game_map):
            if 1 in row:  # Bu satırda platform var
                ground_row = row_idx
                break
        
        # Oyuncu zeminin üstünde olmalı
        self.y = ground_row * TILE_SIZE - PLAYER_HEIGHT
        
        self.rect.x = self.x
        self.rect.y = self.y
        self.velocity_x = 0
        self.velocity_y = 0
        self.on_ground = False


class NPC:
    """Hedef NPC karakteri"""
    def __init__(self, x, y, idle_sprite):
        self.x = x
        self.y = y
        self.rect = pygame.Rect(x, y, PLAYER_WIDTH, PLAYER_HEIGHT)
        
        # Sprite yükle ve ölçeklendir
        raw_idle = pygame.image.load(idle_sprite).convert_alpha()
        self.image = pygame.transform.scale(raw_idle, (PLAYER_WIDTH, PLAYER_HEIGHT))
    
    def draw(self, screen):
        """Çiz"""
        screen.blit(self.image, (self.x, self.y))



class Enemy:
    """Düşman canavar - sağa sola hareket eder"""
    def __init__(self, x, y, patrol_distance=120, level=0):
        self.start_x = x
        self.x = x
        self.y = y
        self.width = 32
        self.height = 32
        self.rect = pygame.Rect(x, y, self.width, self.height)
        # Bölüme göre hız artışı: Bölüm 1: 1.5, Bölüm 2: 2.0, Bölüm 3: 2.5
        self.speed = 1.5 + (level * 0.5)
        self.direction = 1  # 1: sağa, -1: sola
        self.patrol_distance = patrol_distance
        self.alive = True
    
    def update(self):
        """Hareket et"""
        if not self.alive:
            return
        
        # Sağa sola hareket
        self.x += self.speed * self.direction
        
        # Patrol sınırlarını kontrol et
        if self.x > self.start_x + self.patrol_distance:
            self.direction = -1
        elif self.x < self.start_x - self.patrol_distance:
            self.direction = 1
        
        self.rect.x = self.x
    
    def draw(self, screen):
        """Çiz"""
        if not self.alive:
            return
        
        # Canavar gövdesi (kırmızı)
        pygame.draw.rect(screen, (200, 50, 50), self.rect)
        pygame.draw.rect(screen, (150, 30, 30), self.rect, 2)
        
        # Gözler
        eye_y = self.y + 8
        if self.direction == 1:  # Sağa bakıyor
            pygame.draw.circle(screen, WHITE, (int(self.x + 18), eye_y), 4)
            pygame.draw.circle(screen, WHITE, (int(self.x + 26), eye_y), 4)
            pygame.draw.circle(screen, BLACK, (int(self.x + 20), eye_y), 2)
            pygame.draw.circle(screen, BLACK, (int(self.x + 28), eye_y), 2)
        else:  # Sola bakıyor
            pygame.draw.circle(screen, WHITE, (int(self.x + 6), eye_y), 4)
            pygame.draw.circle(screen, WHITE, (int(self.x + 14), eye_y), 4)
            pygame.draw.circle(screen, BLACK, (int(self.x + 4), eye_y), 2)
            pygame.draw.circle(screen, BLACK, (int(self.x + 12), eye_y), 2)
        
        # Ağız (kızgın)
        mouth_y = self.y + 22
        pygame.draw.line(screen, BLACK, (int(self.x + 8), mouth_y), (int(self.x + 24), mouth_y), 2)
    
    def check_player_collision(self, player):
        """Oyuncu ile çarpışma kontrolü"""
        if not self.alive:
            return None
        
        if self.rect.colliderect(player.rect):
            # Oyuncu yukarıdan geliyorsa (üzerine zıpladıysa)
            if player.velocity_y > 0 and player.rect.bottom - 10 < self.rect.top:
                self.alive = False
                player.velocity_y = -10  # Zıplama efekti
                return "killed"
            else:
                # Yandan çarptı - hasar al
                return "damage"
        return None


class Raindrop:
    """Yağmur damlası - yukarıdan düşer ve hasar verir"""
    def __init__(self, x, y, level=0):
        self.x = x
        self.y = y
        self.width = 8
        self.height = 16
        self.rect = pygame.Rect(x, y, self.width, self.height)
        # Bölüme göre hız artışı: Bölüm 1: 4, Bölüm 2: 5, Bölüm 3: 6
        self.speed = 4 + level
        self.hit_player = False
    
    def update(self):
        """Aşağı düş"""
        self.y += self.speed
        self.rect.y = self.y
    
    def draw(self, screen):
        """Damla çiz"""
        # Mavi damla
        pygame.draw.ellipse(screen, (100, 150, 255), self.rect)
        pygame.draw.ellipse(screen, (70, 120, 200), self.rect, 1)
    
    def is_offscreen(self):
        """Ekran dışına çıktı mı?"""
        return self.y > SCREEN_HEIGHT
    
    def check_player_collision(self, player):
        """Oyuncu ile çarpışma kontrolü"""
        if not self.hit_player and self.rect.colliderect(player.rect):
            self.hit_player = True
            return True
        return False
