#!/usr/bin/env python3
"""HTML dosyasını düzenleyerek canvas boyutunu ve CSS'i düzeltir"""

import re

html_path = "web/build/web/index.html"

# HTML'i oku
with open(html_path, 'r', encoding='utf-8') as f:
    html = f.read()

# 1. Framebuffer boyutunu değiştir (1280x720 -> 800x600)
html = re.sub(
    r'fb_ar\s*:\s*1\.77,\s*\n\s*fb_width\s*:\s*"1280",\s*\n\s*fb_height\s*:\s*"720"',
    'fb_ar   :  1.33,\n    fb_width : "800",\n    fb_height : "600"',
    html
)

# 2. Canvas CSS'ini değiştir
old_canvas_css = r'/\* the canvas \*must not\* have any border or padding, or mouse coords will be wrong \*/\s*\n\s*/\* average size of droid screen 470dp x 320dp\s*\*/\s*\n\s*canvas\.emscripten \{\s*\n\s*border: 0px none;\s*\n\s*background-color: transparent;\s*\n\s*width: 100%;\s*\n\s*height: 100%;\s*\n\s*z-index: 5;'

new_canvas_css = '''/* the canvas *must not* have any border or padding, or mouse coords will be wrong */
        /* Full screen with aspect ratio preserved */
        canvas.emscripten {
            border: 0px none;
            background-color: black;
            width: 100vw !important;
            height: 100vh !important;
            max-width: 133.33vh !important;
            max-height: 75vw !important;
            object-fit: contain;
            z-index: 5;'''

html = re.sub(old_canvas_css, new_canvas_css, html, flags=re.MULTILINE)

# 3. Body CSS'ini değiştir
old_body_css = r'body \{\s*\n\s*font-family: arial;\s*\n\s*margin: 0;\s*\n\s*padding: none;\s*\n\s*background-color:\s*powderblue;\s*\n\s*\}'

new_body_css = '''body {
            font-family: arial;
            margin: 0;
            padding: 0;
            background-color: black;
            overflow: hidden;
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100vw;
            height: 100vh;
        }'''

html = re.sub(old_body_css, new_body_css, html, flags=re.MULTILINE)

# HTML'i kaydet
with open(html_path, 'w', encoding='utf-8') as f:
    f.write(html)

print("✓ HTML düzeltildi!")
print("  - Framebuffer: 800x600")
print("  - Canvas: Tam ekran, 4:3 oran korunuyor")
print("  - Body: Siyah arka plan, ortalanmış")
