# Sabitler ve renkler

# Ekran ayarları
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
TILE_SIZE = 40
PLAYER_WIDTH = 48  # 32'den 48'e büyüttük
PLAYER_HEIGHT = 64  # 48'den 64'e büyüttük
FPS = 60

# Fizik
GRAVITY = 0.8
JUMP_STRENGTH = -15

# Renkler
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 100, 100)
PINK = (255, 200, 220)
PASTEL_BLUE = (200, 220, 255)
DARK_RED = (200, 50, 50)
SKY_BLUE = (135, 206, 250)
BROWN = (139, 69, 19)
DARK_BROWN = (101, 67, 33)

# Oyun durumları
FIRST_SCREEN = "first_screen"
MENU = "menu"
CHARACTER_SELECT = "character_select"
CHARACTER_CHOSEN = "character_chosen"
LEVEL_INTRO = "level_intro"
PLAY = "play"
LEVEL_COMPLETE = "level_complete"
NIDA_B4 = "nida_b4"
WIN = "win"
FINAL_LETTER = "final_letter"
GAME_OVER = "game_over"
