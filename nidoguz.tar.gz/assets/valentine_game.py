import pygame
import sys
from constants import *
from levels import *
from entities import Player, NPC, Coin, Enemy, Raindrop
from game_screens import *
from backgrounds import init_backgrounds

# Pygame başlat
pygame.init()

class Game:
    """Ana oyun sınıfı"""
    def __init__(self):
        # Tam ekran bilgisi al
        display_info = pygame.display.Info()
        self.display_width = display_info.current_w
        self.display_height = display_info.current_h
        
        # Web'de otomatik tam ekran, masaüstünde pencere modu
        import sys
        import platform
        is_web = sys.platform == "emscripten" or platform.system() == "Emscripten"
        
        self.fullscreen = is_web  # Web'de tam ekran
        if self.fullscreen:
            self.display_surface = pygame.display.set_mode((self.display_width, self.display_height), pygame.FULLSCREEN)
        else:
            # Masaüstünde pencere modu - orijinal boyut
            self.display_surface = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.RESIZABLE)
        
        # Oyun ekranı (sanal ekran - orijinal boyutlarda)
        self.screen = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        
        # Ölçekleme hesapla (tam ekran için)
        scale_x = self.display_width / SCREEN_WIDTH
        scale_y = self.display_height / SCREEN_HEIGHT
        self.scale = min(scale_x, scale_y)
        
        # Ölçeklenmiş boyutlar
        self.scaled_width = int(SCREEN_WIDTH * self.scale)
        self.scaled_height = int(SCREEN_HEIGHT * self.scale)
        
        # Ortalama için offset
        self.offset_x = (self.display_width - self.scaled_width) // 2
        self.offset_y = (self.display_height - self.scaled_height) // 2
        
        pygame.display.set_caption("nidoguz")
        
        # İkon ayarla
        try:
            icon = pygame.image.load("icon.png")
            pygame.display.set_icon(icon)
        except:
            pass  # İkon yüklenemezse devam et
        
        self.clock = pygame.time.Clock()
        self.running = True
        
        # Arka planları cache'le (optimizasyon) - Display oluşturulduktan SONRA!
        init_backgrounds()
        
        self.state = FIRST_SCREEN
        self.selected_character = None
        self.menu_selection = 0
        
        self.font = pygame.font.Font(None, 36)
        self.small_font = pygame.font.Font(None, 24)
        self.digital_font = pygame.font.SysFont('consolas', 48, bold=True)
        
        # First screen yükle (foreground_first.png)
        try:
            raw_first = pygame.image.load("foreground_first.png").convert()
            self.first_screen = pygame.transform.scale(raw_first, (SCREEN_WIDTH, SCREEN_HEIGHT))
            print("✓ foreground_first.png yüklendi!")
        except Exception as e:
            print(f"foreground_first.png yüklenemedi: {e}")
            self.first_screen = None
        
        # Background images yükle
        try:
            raw_bg = pygame.image.load("background.png").convert()
            self.background = pygame.transform.scale(raw_bg, (SCREEN_WIDTH, SCREEN_HEIGHT))
        except:
            self.background = None
        
        try:
            raw_choose = pygame.image.load("choose.png").convert()
            self.choose_screen = pygame.transform.scale(raw_choose, (SCREEN_WIDTH, SCREEN_HEIGHT))
        except:
            self.choose_screen = None
        
        try:
            raw_oguz_chosen = pygame.image.load("oguz_chosen.png").convert()
            self.oguz_chosen_screen = pygame.transform.scale(raw_oguz_chosen, (SCREEN_WIDTH, SCREEN_HEIGHT))
        except:
            self.oguz_chosen_screen = None
        
        try:
            raw_nida_chosen = pygame.image.load("nida_chosen.png").convert()
            self.nida_chosen_screen = pygame.transform.scale(raw_nida_chosen, (SCREEN_WIDTH, SCREEN_HEIGHT))
        except:
            self.nida_chosen_screen = None
        
        # Hedef image'i yükle (narlica.png) - ÇOK BÜYÜK
        try:
            raw_goal = pygame.image.load("narlica.png").convert_alpha()
            # Çok daha büyük yap - 4x tile size
            self.goal_image = pygame.transform.scale(raw_goal, (TILE_SIZE * 4, TILE_SIZE * 4))
            print("✓ narlica.png yüklendi (4x büyük)!")
        except Exception as e:
            print(f"narlica.png yüklenemedi: {e}")
            self.goal_image = None
        
        # Bölüm 2 hedef image'i yükle (koltuk.png)
        try:
            raw_goal2 = pygame.image.load("koltuk.png").convert_alpha()
            self.goal_image_level2 = pygame.transform.scale(raw_goal2, (TILE_SIZE * 4, TILE_SIZE * 4))
            print("✓ koltuk.png yüklendi (4x büyük)!")
        except Exception as e:
            print(f"koltuk.png yüklenemedi: {e}")
            self.goal_image_level2 = None
        
        # Bölüm 3 hedef image'i yükle (baltur.png)
        try:
            raw_goal3 = pygame.image.load("baltur.png").convert_alpha()
            self.goal_image_level3 = pygame.transform.scale(raw_goal3, (TILE_SIZE * 4, TILE_SIZE * 4))
            print("✓ baltur.png yüklendi (4x büyük)!")
        except Exception as e:
            print(f"baltur.png yüklenemedi: {e}")
            self.goal_image_level3 = None
        
        # Game Over ekranı yükle (basaramadin.png)
        try:
            raw_gameover = pygame.image.load("basaramadin.png").convert()
            self.gameover_screen = pygame.transform.scale(raw_gameover, (SCREEN_WIDTH, SCREEN_HEIGHT))
            print("✓ basaramadin.png yüklendi!")
        except Exception as e:
            print(f"basaramadin.png yüklenemedi: {e}")
            self.gameover_screen = None
        
        # Nida final ekranı yükle (nidafinal.png)
        try:
            raw_nidafinal = pygame.image.load("nidafinal.png").convert()
            self.nidafinal_screen = pygame.transform.scale(raw_nidafinal, (SCREEN_WIDTH, SCREEN_HEIGHT))
            print("✓ nidafinal.png yüklendi!")
        except Exception as e:
            print(f"nidafinal.png yüklenemedi: {e}")
            self.nidafinal_screen = None
        
        # Final letter ekranı yükle (final_letter.png)
        try:
            raw_final_letter = pygame.image.load("final_letter.png").convert()
            self.final_letter_screen = pygame.transform.scale(raw_final_letter, (SCREEN_WIDTH, SCREEN_HEIGHT))
            print("✓ final_letter.png yüklendi!")
        except Exception as e:
            print(f"final_letter.png yüklenemedi: {e}")
            self.final_letter_screen = None
        
        # Nida B4 ekranı yükle (nida_b4.png) - 3. bölüm sonrası
        try:
            raw_nida_b4 = pygame.image.load("nida_b4.png").convert()
            self.nida_b4_screen = pygame.transform.scale(raw_nida_b4, (SCREEN_WIDTH, SCREEN_HEIGHT))
            print("✓ nida_b4.png yüklendi!")
        except Exception as e:
            print(f"nida_b4.png yüklenemedi: {e}")
            self.nida_b4_screen = None
        
        # Kalp ikonu yükle (can göstergesi için)
        try:
            raw_heart = pygame.image.load("kalp.png").convert_alpha()
            self.heart_icon = pygame.transform.scale(raw_heart, (30, 30))
            print("✓ kalp.png yüklendi!")
        except Exception as e:
            print(f"kalp.png yüklenemedi: {e}")
            self.heart_icon = None

        # Oyun objeleri
        self.player = None
        self.npc = None
        self.coins = []
        self.enemies = []
        self.raindrops = []
        self.rain_timer = 0
        self.rain_spawn_interval = 30  # Her 30 frame'de bir damla (daha az yağmur)
        
        # Bölüm sistemi
        self.current_level = 0
        self.level_time = 0
        self.level_start_time = 0
    
    def init_game(self):
        """Oyunu başlat"""
        if self.selected_character == "oguz":
            player_idle = "me_idle.png"
            player_walk = "me_walk.png"
            player_walk_other = None  # Oğuz için ikinci sprite yok
            player_idle_back = None
            player_walk_back = None
            player_walk_other_back = None
            npc_idle = "partner_idle.png"
        else:
            player_idle = "partner_idle.png"
            player_walk = "partner_walk.png"
            player_walk_other = "partner_walk_other.png"  # Nida için animasyon
            player_idle_back = "partner_idle_back.png"
            player_walk_back = "partner_walk_back.png"
            player_walk_other_back = "partner_walk_other_back.png"
            npc_idle = "me_idle.png"
        
        # Oyuncuyu oluştur (başlangıç pozisyonu load_level'da ayarlanacak)
        start_x = TILE_SIZE
        start_y = TILE_SIZE  # Geçici, load_level düzeltecek
        self.player = Player(start_x, start_y, player_idle, player_walk, player_walk_other, 
                            player_idle_back, player_walk_back, player_walk_other_back)
        self.npc_idle_sprite = npc_idle
        self.current_level = 0
        self.load_level(0)
    
    def load_level(self, level_index):
        """Bölümü yükle"""
        self.current_level = level_index
        current_map = LEVELS[level_index]
        
        self.player.reset_for_level(current_map, level_index)
        
        # Coin'leri ve düşmanları bul
        self.coins = []
        self.enemies = []
        self.raindrops = []
        self.rain_timer = 0
        
        for row_idx, row in enumerate(current_map):
            for col_idx, tile in enumerate(row):
                if tile == 2:
                    coin_x = col_idx * TILE_SIZE
                    coin_y = row_idx * TILE_SIZE
                    self.coins.append(Coin(coin_x, coin_y))
                elif tile == 4:  # Düşman spawn
                    enemy_x = col_idx * TILE_SIZE
                    enemy_y = row_idx * TILE_SIZE  # Kalplerle aynı hizada
                    self.enemies.append(Enemy(enemy_x, enemy_y, level=level_index))
        
        # NPC sadece son bölümde
        self.npc = None
        if level_index == 3:
            for row_idx, row in enumerate(current_map):
                for col_idx, tile in enumerate(row):
                    if tile == 3:
                        npc_x = col_idx * TILE_SIZE
                        npc_y = row_idx * TILE_SIZE - PLAYER_HEIGHT + TILE_SIZE
                        self.npc = NPC(npc_x, npc_y, self.npc_idle_sprite)
        
        # Hedef pozisyonu
        self.goal_pos = None
        for row_idx, row in enumerate(current_map):
            for col_idx, tile in enumerate(row):
                if tile == 3:
                    self.goal_pos = (col_idx * TILE_SIZE, row_idx * TILE_SIZE)
        
        self.level_start_time = pygame.time.get_ticks()

    def handle_events(self):
        """Olayları işle"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            
            # Pencere yeniden boyutlandırma (masaüstünde)
            if event.type == pygame.VIDEORESIZE and not self.fullscreen:
                # En-boy oranını koru
                aspect_ratio = SCREEN_WIDTH / SCREEN_HEIGHT
                new_width = event.w
                new_height = event.h
                
                if new_width / new_height > aspect_ratio:
                    # Çok geniş - yüksekliğe göre ayarla
                    new_width = int(new_height * aspect_ratio)
                else:
                    # Çok dar - genişliğe göre ayarla
                    new_height = int(new_width / aspect_ratio)
                
                self.display_surface = pygame.display.set_mode((new_width, new_height), pygame.RESIZABLE)
                self.display_width = new_width
                self.display_height = new_height
                
                # Ölçekleme hesapla
                scale_x = self.display_width / SCREEN_WIDTH
                scale_y = self.display_height / SCREEN_HEIGHT
                self.scale = min(scale_x, scale_y)
                
                # Ölçeklenmiş boyutlar
                self.scaled_width = int(SCREEN_WIDTH * self.scale)
                self.scaled_height = int(SCREEN_HEIGHT * self.scale)
                
                # Ortalama için offset
                self.offset_x = (self.display_width - self.scaled_width) // 2
                self.offset_y = (self.display_height - self.scaled_height) // 2
            
            if event.type == pygame.KEYDOWN:
                # ESC tuşu ile çıkış
                if event.key == pygame.K_ESCAPE:
                    self.running = False
                
                # F11 tuşu ile tam ekran geçişi
                if event.key == pygame.K_F11:
                    self.toggle_fullscreen()
                
                # TEST: T tuşu ile direkt Bölüm 4'e git
                if event.key == pygame.K_t and self.state == MENU:
                    self.selected_character = "nida"  # Varsayılan karakter
                    self.init_game()
                    self.load_level(3)  # Bölüm 4
                    self.state = PLAY
                    print("TEST MODE: Bölüm 4'e atlandı!")
                
                if self.state == FIRST_SCREEN:
                    if event.key in [pygame.K_RETURN, pygame.K_SPACE]:
                        self.state = MENU
                
                elif self.state == MENU:
                    if event.key == pygame.K_RETURN:
                        self.state = CHARACTER_SELECT
                
                elif self.state == CHARACTER_SELECT:
                    if event.key in [pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT, pygame.K_RIGHT]:
                        self.menu_selection = 1 - self.menu_selection
                    elif event.key == pygame.K_RETURN:
                        self.selected_character = "oguz" if self.menu_selection == 0 else "nida"
                        self.state = CHARACTER_CHOSEN
                
                elif self.state == CHARACTER_CHOSEN:
                    if event.key == pygame.K_RETURN:
                        self.init_game()
                        self.state = LEVEL_INTRO
                
                elif self.state == LEVEL_INTRO:
                    if event.key in [pygame.K_RETURN, pygame.K_SPACE]:
                        self.state = PLAY
                
                elif self.state == NIDA_B4:
                    if event.key in [pygame.K_RETURN, pygame.K_SPACE]:
                        # 4. bölüme direkt geç (intro ekranı yok)
                        self.load_level(3)
                        self.state = PLAY
                
                elif self.state == PLAY:
                    if event.key in [pygame.K_SPACE, pygame.K_w, pygame.K_UP]:
                        self.player.jump()
                
                elif self.state in [GAME_OVER, WIN]:
                    if event.key == pygame.K_r:
                        self.current_level = 0
                        self.init_game()
                        self.state = LEVEL_INTRO
                    elif event.key == pygame.K_m:
                        self.state = MENU
                
                elif self.state == FINAL_LETTER:
                    # Final letter'dan çıkış
                    if event.key in [pygame.K_RETURN, pygame.K_SPACE, pygame.K_ESCAPE]:
                        self.state = MENU

            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                
                # Tam ekran modundaysa mouse pozisyonunu sanal ekran koordinatlarına çevir
                if self.fullscreen:
                    adjusted_x = (mouse_pos[0] - self.offset_x) / self.scale
                    adjusted_y = (mouse_pos[1] - self.offset_y) / self.scale
                    mouse_pos = (adjusted_x, adjusted_y)
                
                if self.state == FIRST_SCREEN:
                    # Herhangi bir yere tıklanınca menüye geç
                    self.state = MENU
                
                elif self.state == MENU:
                    play_rect = pygame.Rect(360, 340, 280, 80)
                    if play_rect.collidepoint(mouse_pos):
                        self.state = CHARACTER_SELECT
                
                elif self.state == CHARACTER_SELECT:
                    oguz_rect = pygame.Rect(200, 450, 180, 70)
                    if oguz_rect.collidepoint(mouse_pos):
                        self.selected_character = "oguz"
                        self.state = CHARACTER_CHOSEN
                    nida_rect = pygame.Rect(420, 450, 180, 70)
                    if nida_rect.collidepoint(mouse_pos):
                        self.selected_character = "nida"
                        self.state = CHARACTER_CHOSEN
                    back_rect = pygame.Rect(10, 10, 80, 40)
                    if back_rect.collidepoint(mouse_pos):
                        self.state = MENU
                
                elif self.state == CHARACTER_CHOSEN:
                    start_rect = pygame.Rect(300, 480, 200, 70)
                    if start_rect.collidepoint(mouse_pos):
                        self.init_game()
                        self.state = LEVEL_INTRO
                    back_rect = pygame.Rect(10, 10, 80, 40)
                    if back_rect.collidepoint(mouse_pos):
                        self.state = CHARACTER_SELECT
                
                elif self.state == LEVEL_INTRO:
                    self.state = PLAY
                
                elif self.state == LEVEL_COMPLETE:
                    if self.current_level < 3:
                        self.load_level(self.current_level + 1)
                        self.state = LEVEL_INTRO
                    else:
                        self.state = WIN
                
                elif self.state == WIN:
                    # Nida karakteriyse ve nidafinal ekranındaysa OKU butonunu kontrol et
                    if self.selected_character == "nida":
                        # OKU butonu koordinatları (resme göre tahmin - alt ortada)
                        oku_button_rect = pygame.Rect(300, 520, 200, 60)  # OKU butonunun tahmini konumu
                        if oku_button_rect.collidepoint(mouse_pos):
                            self.state = FINAL_LETTER
                
                elif self.state == FINAL_LETTER:
                    # Ana Menü butonu (sol alt köşe) - çok geniş alan
                    menu_button_rect = pygame.Rect(0, SCREEN_HEIGHT - 100, 220, 100)
                    if menu_button_rect.collidepoint(mouse_pos):
                        self.state = MENU
                    
                    # TEKRAR SARIL butonu (sağ alt, mektubun içinde) - çok geniş alan
                    tekrar_saril_rect = pygame.Rect(450, 480, 350, 120)
                    if tekrar_saril_rect.collidepoint(mouse_pos):
                        # Bölüm 4'ü yeniden başlat
                        self.load_level(3)
                        self.state = PLAY
    
    def update(self):
        """Oyun mantığını güncelle"""
        if self.state == PLAY:
            current_map = LEVELS[self.current_level]
            
            # Klavye kontrolü
            keys = pygame.key.get_pressed()
            dx = 0
            if keys[pygame.K_a] or keys[pygame.K_LEFT]:
                dx = -1
            if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
                dx = 1
            
            self.player.move(dx, current_map)
            self.player.update(current_map)
            
            # Düşmanları güncelle
            for enemy in self.enemies:
                enemy.update()
                result = enemy.check_player_collision(self.player)
                if result == "damage":
                    self.player.take_damage()
                    # Oyuncuyu geri it
                    self.player.x -= 20 if self.player.velocity_x > 0 else -20
                    self.player.rect.x = self.player.x
                elif result == "killed":
                    self.player.add_score(20)  # Canavar öldürme bonusu
                    self.player.enemy_killed()  # Düşman sayacını artır ve can kontrolü yap
            
            # Yağmur damlaları (Bölüm 1, 2, 3'te)
            if self.current_level in [0, 1, 2]:  # Bölüm 1, 2, 3
                self.rain_timer += 1
                if self.rain_timer >= self.rain_spawn_interval:
                    self.rain_timer = 0
                    # Rastgele x pozisyonunda damla oluştur
                    import random
                    rain_x = random.randint(0, SCREEN_WIDTH - 8)
                    self.raindrops.append(Raindrop(rain_x, -20, level=self.current_level))
                
                # Damlaları güncelle
                for raindrop in self.raindrops[:]:
                    raindrop.update()
                    if raindrop.check_player_collision(self.player):
                        self.player.take_damage()
                        self.raindrops.remove(raindrop)
                    elif raindrop.is_offscreen():
                        self.raindrops.remove(raindrop)
            
            # Coin toplama
            for coin in self.coins:
                if not coin.collected and self.player.rect.colliderect(coin.rect):
                    coin.collected = True
                    self.player.add_score(10)
            
            # Tüm coinler toplandı mı?
            all_coins_collected = all(coin.collected for coin in self.coins)
            
            # Hedefe ulaşma
            if self.goal_pos:
                goal_rect = pygame.Rect(self.goal_pos[0], self.goal_pos[1], TILE_SIZE, TILE_SIZE)
                if self.player.rect.colliderect(goal_rect) and all_coins_collected:
                    # 3. bölüm bittiyse ve Nida karakteriyse nida_b4 ekranını göster
                    if self.current_level == 2:  # Bölüm 3 (index 2)
                        self.state = NIDA_B4
                    # Direkt sonraki bölüme geç (intro ekranına)
                    elif self.current_level < 3:
                        self.load_level(self.current_level + 1)
                        self.state = LEVEL_INTRO
                    else:
                        self.state = WIN
            
            # Can kontrolü
            if self.player.health <= 0:
                self.state = GAME_OVER

    def draw(self):
        """Ekrana çiz"""
        if self.state == FIRST_SCREEN:
            draw_first_screen(self)
        elif self.state == MENU:
            draw_menu(self)
        elif self.state == CHARACTER_SELECT:
            draw_character_select(self)
        elif self.state == CHARACTER_CHOSEN:
            draw_character_chosen(self)
        elif self.state == LEVEL_INTRO:
            draw_level_intro(self)
        elif self.state == PLAY:
            draw_game(self)
        elif self.state == NIDA_B4:
            draw_nida_b4(self)
        elif self.state == WIN:
            draw_win(self)
        elif self.state == FINAL_LETTER:
            draw_final_letter(self)
        elif self.state == GAME_OVER:
            draw_game_over(self)
        
        # Her durumda ölçekle ve çiz (tam ekran veya pencere)
        if self.fullscreen or self.display_surface.get_size() != (SCREEN_WIDTH, SCREEN_HEIGHT):
            # Ölçekleme gerekli
            self.display_surface.fill((0, 0, 0))  # Siyah arka plan (letterbox)
            scaled_screen = pygame.transform.scale(self.screen, (self.scaled_width, self.scaled_height))
            self.display_surface.blit(scaled_screen, (self.offset_x, self.offset_y))
        else:
            # Direkt çiz (orijinal boyut)
            self.display_surface.blit(self.screen, (0, 0))
        
        pygame.display.flip()
    
    def toggle_fullscreen(self):
        """Tam ekran modunu aç/kapat"""
        self.fullscreen = not self.fullscreen
        
        if self.fullscreen:
            self.display_surface = pygame.display.set_mode((self.display_width, self.display_height), pygame.FULLSCREEN)
        else:
            self.display_surface = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.RESIZABLE)
        
        # Ölçekleme hesapla
        scale_x = self.display_width / SCREEN_WIDTH
        scale_y = self.display_height / SCREEN_HEIGHT
        self.scale = min(scale_x, scale_y)
        
        # Ölçeklenmiş boyutlar
        self.scaled_width = int(SCREEN_WIDTH * self.scale)
        self.scaled_height = int(SCREEN_HEIGHT * self.scale)
        
        # Ortalama için offset
        self.offset_x = (self.display_width - self.scaled_width) // 2
        self.offset_y = (self.display_height - self.scaled_height) // 2
        
        pygame.display.set_caption("nidoguz")
    
    def run(self):
        """Ana oyun döngüsü"""
        while self.running:
            self.handle_events()
            self.update()
            self.draw()
            self.clock.tick(FPS)
        
        pygame.quit()
        sys.exit()
    
    def run_frame(self):
        """Tek frame çalıştır (web için)"""
        self.handle_events()
        self.update()
        self.draw()
        self.clock.tick(FPS)


# Oyunu başlat
if __name__ == "__main__":
    game = Game()
    game.run()
