#!/usr/bin/env python3
"""HTML'e basit CSS ekleyerek canvas'ı tam ekran yapar"""

html_path = "web/build/web/index.html"

# HTML'i oku
with open(html_path, 'r', encoding='utf-8') as f:
    html = f.read()

# </style> tag'inden önce yeni CSS ekle
extra_css = """
        /* Tam ekran canvas - en-boy oranı korunuyor */
        canvas.emscripten {
            position: fixed !important;
            top: 50% !important;
            left: 50% !important;
            transform: translate(-50%, -50%) !important;
            width: auto !important;
            height: auto !important;
            max-width: 100vw !important;
            max-height: 100vh !important;
        }
        
        body {
            background-color: #000 !important;
            overflow: hidden !important;
        }
    </style>"""

html = html.replace('</style>', extra_css)

# HTML'i kaydet
with open(html_path, 'w', encoding='utf-8') as f:
    f.write(html)

print("✓ CSS eklendi - canvas tam ekran olacak!")
