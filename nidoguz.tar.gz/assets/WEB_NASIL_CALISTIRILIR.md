# 🎮 Valentine Oyunu - Web Versiyonu Nasıl Çalıştırılır?

## Hızlı Başlangıç

### Yöntem 1: Otomatik (Önerilen)
1. `RUN_WEB.bat` dosyasına çift tıkla
2. Tarayıcı otomatik açılacak
3. Oyunu oyna!

### Yöntem 2: Manuel
1. Komut satırını aç
2. Şu komutları çalıştır:
```bash
python -m pygbag --build web
python -m http.server 8000 --directory web/build/web
```
3. Tarayıcıda aç: http://localhost:8000

## Gereksinimler
- Python 3.8+
- pygbag (kurulu: 0.9.3 ✅)
- pygame

## Sorun Giderme

### Oyun yüklenmiyor
- Tarayıcı konsolunu aç (F12)
- Hataları kontrol et
- Sayfayı yenile (Ctrl+F5)

### Siyah ekran
- 5-10 saniye bekle (ilk yükleme uzun sürebilir)
- Tarayıcı cache'ini temizle

### Kontroller çalışmıyor
- Oyun canvas'ına tıkla (focus için)
- Klavye: A/D (hareket), SPACE (zıpla)

## Özellikler
- ✅ 800x600 çözünürlük
- ✅ Tam ekran desteği
- ✅ Tüm görseller dahil
- ✅ 4 bölüm
- ✅ 2 karakter seçimi

## Port Değiştirme
Eğer 8000 portu kullanımdaysa:
```bash
python -m http.server 8080 --directory web/build/web
```
Sonra: http://localhost:8080

## Notlar
- İlk yükleme 5-10 saniye sürebilir
- Tüm varlıklar (görseller, sesler) web'e paketlendi
- Offline çalışır (internet gerekmez)
