# Oyun ekranlarını çizen fonksiyonlar
import pygame
from constants import *
from backgrounds import draw_level_background, init_backgrounds

def draw_first_screen(game):
    """İlk açılış ekranı - foreground_first.png"""
    if game.first_screen:
        game.screen.blit(game.first_screen, (0, 0))
    else:
        # Fallback: Resim yüklenemezse basit ekran
        game.screen.fill(PASTEL_BLUE)
        title = game.font.render("💖 Sevgililer Günü Oyunu 💖", True, RED)
        game.screen.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 250))
        
        continue_text = game.small_font.render("Enter/Space ile devam et", True, BLACK)
        game.screen.blit(continue_text, (SCREEN_WIDTH // 2 - continue_text.get_width() // 2, 350))

def draw_menu(game):
    """Ana menü"""
    if game.background:
        game.screen.blit(game.background, (0, 0))
    else:
        game.screen.fill(PASTEL_BLUE)
        title = game.font.render("💖 Sevgililer Günü Oyunu 💖", True, RED)
        game.screen.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 200))
        
        play_rect = pygame.Rect(SCREEN_WIDTH // 2 - 80, 380, 160, 60)
        pygame.draw.rect(game.screen, RED, play_rect, border_radius=15)
        pygame.draw.rect(game.screen, WHITE, play_rect, 3, border_radius=15)
        play_text = game.digital_font.render("OYNA", True, WHITE)
        game.screen.blit(play_text, (SCREEN_WIDTH // 2 - play_text.get_width() // 2, 388))

def draw_character_select(game):
    """Karakter seçimi"""
    if game.choose_screen:
        game.screen.blit(game.choose_screen, (0, 0))
    else:
        game.screen.fill(PASTEL_BLUE)
        title = game.font.render("Karakterini Seç", True, RED)
        game.screen.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 100))
    
    # Geri butonu
    back_rect = pygame.Rect(10, 10, 80, 40)
    pygame.draw.rect(game.screen, (100, 100, 100), back_rect, border_radius=8)
    pygame.draw.rect(game.screen, WHITE, back_rect, 2, border_radius=8)
    back_text = game.small_font.render("← Geri", True, WHITE)
    game.screen.blit(back_text, (back_rect.centerx - back_text.get_width() // 2, back_rect.centery - back_text.get_height() // 2))

def draw_character_chosen(game):
    """Karakter seçildi"""
    if game.selected_character == "oguz" and game.oguz_chosen_screen:
        game.screen.blit(game.oguz_chosen_screen, (0, 0))
    elif game.selected_character == "nida" and game.nida_chosen_screen:
        game.screen.blit(game.nida_chosen_screen, (0, 0))
    else:
        game.screen.fill(PINK)
        chosen_text = game.font.render(f"{'Oğuz' if game.selected_character == 'oguz' else 'Nida'} Seçildi!", True, RED)
        game.screen.blit(chosen_text, (SCREEN_WIDTH // 2 - chosen_text.get_width() // 2, 200))
    
    # Geri butonu
    back_rect = pygame.Rect(10, 10, 80, 40)
    pygame.draw.rect(game.screen, (100, 100, 100), back_rect, border_radius=8)
    pygame.draw.rect(game.screen, WHITE, back_rect, 2, border_radius=8)
    back_text = game.small_font.render("← Geri", True, WHITE)
    game.screen.blit(back_text, (back_rect.centerx - back_text.get_width() // 2, back_rect.centery - back_text.get_height() // 2))


def draw_level_intro(game):
    """Bölüm giriş ekranı"""
    # Bölüm 1 için özel ekran
    if game.current_level == 0:
        try:
            intro_img = pygame.image.load("nida_b1.png").convert()
            intro_img = pygame.transform.scale(intro_img, (SCREEN_WIDTH, SCREEN_HEIGHT))
            game.screen.blit(intro_img, (0, 0))
            return
        except Exception as e:
            print(f"nida_b1.png yüklenemedi: {e}")
    
    # Bölüm 2 için özel ekran
    if game.current_level == 1:
        try:
            intro_img = pygame.image.load("nida_b2.png").convert()
            intro_img = pygame.transform.scale(intro_img, (SCREEN_WIDTH, SCREEN_HEIGHT))
            game.screen.blit(intro_img, (0, 0))
            return
        except Exception as e:
            print(f"nida_b2.png yüklenemedi: {e}")
    
    # Bölüm 3 için özel ekran
    if game.current_level == 2:
        try:
            intro_img = pygame.image.load("nida_b3.png").convert()
            intro_img = pygame.transform.scale(intro_img, (SCREEN_WIDTH, SCREEN_HEIGHT))
            game.screen.blit(intro_img, (0, 0))
            return
        except Exception as e:
            print(f"nida_b3.png yüklenemedi: {e}")
    
    # Diğer bölümler için varsayılan ekran
    game.screen.fill((50, 50, 80))
    
    from levels import LEVEL_NAMES, LEVEL_DESCRIPTIONS
    
    level_title = game.font.render(LEVEL_NAMES[game.current_level], True, PINK)
    game.screen.blit(level_title, (SCREEN_WIDTH // 2 - level_title.get_width() // 2, 150))
    
    level_desc = game.small_font.render(LEVEL_DESCRIPTIONS[game.current_level], True, WHITE)
    game.screen.blit(level_desc, (SCREEN_WIDTH // 2 - level_desc.get_width() // 2, 220))
    
    level_num = game.digital_font.render(f"{game.current_level + 1}/4", True, RED)
    game.screen.blit(level_num, (SCREEN_WIDTH // 2 - level_num.get_width() // 2, 300))
    
    start_text = game.small_font.render("Enter/Space ile başla - SPACE ile zıpla!", True, WHITE)
    game.screen.blit(start_text, (SCREEN_WIDTH // 2 - start_text.get_width() // 2, 450))
    
    # Kalpler
    for i in range(5):
        x = SCREEN_WIDTH // 2 - 100 + i * 50
        pygame.draw.circle(game.screen, RED, (x, 380), 8)
        pygame.draw.circle(game.screen, RED, (x + 10, 380), 8)
        points = [(x - 5, 385), (x + 5, 395), (x + 15, 385)]
        pygame.draw.polygon(game.screen, RED, points)

def draw_level_complete(game):
    """Bölüm tamamlandı"""
    game.screen.fill((80, 50, 80))
    
    if game.current_level < 3:
        title = game.font.render("Bölüm Tamamlandı! 🎉", True, PINK)
    else:
        title = game.font.render("Tüm Bölümler Tamamlandı! 💖", True, PINK)
    game.screen.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 150))
    
    time_text = game.small_font.render(f"Süre: {game.level_time} saniye", True, WHITE)
    game.screen.blit(time_text, (SCREEN_WIDTH // 2 - time_text.get_width() // 2, 250))
    
    score_text = game.small_font.render(f"Skor: {game.player.score}", True, WHITE)
    game.screen.blit(score_text, (SCREEN_WIDTH // 2 - score_text.get_width() // 2, 290))
    
    health_text = game.small_font.render(f"Kalan Can: {game.player.health}", True, WHITE)
    game.screen.blit(health_text, (SCREEN_WIDTH // 2 - health_text.get_width() // 2, 330))
    
    stars = 3 if game.level_time < 30 else 2 if game.level_time < 60 else 1
    star_text = game.font.render("⭐" * stars, True, (255, 215, 0))
    game.screen.blit(star_text, (SCREEN_WIDTH // 2 - star_text.get_width() // 2, 380))
    
    if game.current_level < 3:
        continue_text = game.small_font.render("Enter/Space: Sonraki Bölüm", True, WHITE)
    else:
        continue_text = game.small_font.render("Enter/Space: Final!", True, WHITE)
    game.screen.blit(continue_text, (SCREEN_WIDTH // 2 - continue_text.get_width() // 2, 480))


def draw_game(game):
    """Oyun ekranı - Platformer"""
    from levels import LEVELS
    current_map = LEVELS[game.current_level]
    
    # Bölüme özel arka plan çiz (CACHE'DEN - HIZLI!)
    draw_level_background(game.screen, game.current_level)
    
    # Haritayı çiz
    for row_idx, row in enumerate(current_map):
        for col_idx, tile in enumerate(row):
            x = col_idx * TILE_SIZE
            y = row_idx * TILE_SIZE
            
            if tile == 1:  # Platform/Zemin
                # Bölüm 4'te platformu şeffaf yap (çizme)
                if game.current_level != 3:  # Bölüm 4 değilse çiz
                    pygame.draw.rect(game.screen, WHITE, (x, y, TILE_SIZE, TILE_SIZE))
                    pygame.draw.rect(game.screen, (200, 200, 200), (x, y, TILE_SIZE, TILE_SIZE), 2)
            elif tile == 3:  # Hedef
                # Bölüm 4'te hedef görseli gösterme (şeffaf)
                if game.current_level == 3:
                    pass  # Hiçbir şey çizme
                else:
                    # Diğer bölümler için görseller
                    goal_img = None
                    if game.current_level == 1:  # Bölüm 2
                        goal_img = game.goal_image_level2
                    elif game.current_level == 2:  # Bölüm 3
                        goal_img = game.goal_image_level3
                    else:  # Bölüm 1
                        goal_img = game.goal_image
                    
                    if goal_img:
                        # Büyük resmi çiz (4x4 tile) - sola kaydırılmış
                        game.screen.blit(goal_img, (x - TILE_SIZE * 2.5, y - TILE_SIZE * 3))
                    else:
                        # Fallback: Bayrak
                        pygame.draw.rect(game.screen, (100, 100, 100), (x + 15, y, 5, TILE_SIZE))
                        pygame.draw.polygon(game.screen, RED, [
                            (x + 20, y + 5),
                            (x + 35, y + 12),
                            (x + 20, y + 19)
                        ])
    
    # Coin'leri çiz
    for coin in game.coins:
        coin.draw(game.screen)
    
    # Yağmur damlalarını çiz
    for raindrop in game.raindrops:
        raindrop.draw(game.screen)
    
    # Düşmanları çiz
    for enemy in game.enemies:
        enemy.draw(game.screen)
    
    # NPC
    if game.npc:
        game.npc.draw(game.screen)
    
    # Oyuncu
    if game.player:
        game.player.draw(game.screen)
    
    # HUD
    draw_hud(game)

def draw_hud(game):
    """HUD - Can, skor, bölüm bilgisi"""
    # Can göstergesi - sadece kalp ikonları
    if game.heart_icon:
        for i in range(game.player.health):
            game.screen.blit(game.heart_icon, (10 + i * 35, 10))
    else:
        # Fallback: emoji kullan
        health_text = game.small_font.render(f"{'❤️' * game.player.health}", True, RED)
        game.screen.blit(health_text, (10, 10))
    
    score_text = game.small_font.render(f"Skor: {game.player.score}", True, BLACK)
    game.screen.blit(score_text, (10, 50))
    
    level_text = game.small_font.render(f"Bölüm: {game.current_level + 1}/4", True, BLACK)
    game.screen.blit(level_text, (SCREEN_WIDTH - 120, 10))
    
    elapsed_time = (pygame.time.get_ticks() - game.level_start_time) // 1000
    time_text = game.small_font.render(f"Süre: {elapsed_time}s", True, BLACK)
    game.screen.blit(time_text, (SCREEN_WIDTH - 120, 40))
    
    controls = game.small_font.render("A/D: Hareket | SPACE: Zıpla", True, BLACK)
    game.screen.blit(controls, (SCREEN_WIDTH - 280, 70))

def draw_win(game):
    """Kazanma ekranı - Nida için özel ekran"""
    # Nida karakteriyse nidafinal.png göster
    if game.selected_character == "nida" and game.nidafinal_screen:
        game.screen.blit(game.nidafinal_screen, (0, 0))
    else:
        # Oğuz veya resim yoksa varsayılan ekran
        game.screen.fill(PINK)
        
        win_text = game.font.render("Aşk mektubu ulaştı 💖", True, RED)
        game.screen.blit(win_text, (SCREEN_WIDTH // 2 - win_text.get_width() // 2, 200))
        
        score_text = game.font.render(f"Final Skor: {game.player.score}", True, BLACK)
        game.screen.blit(score_text, (SCREEN_WIDTH // 2 - score_text.get_width() // 2, 280))
        
        restart = game.small_font.render("R: Tekrar Oyna  |  M: Ana Menü", True, BLACK)
        game.screen.blit(restart, (SCREEN_WIDTH // 2 - restart.get_width() // 2, 400))

def draw_final_letter(game):
    """Final letter ekranı - final_letter.png göster"""
    if game.final_letter_screen:
        game.screen.blit(game.final_letter_screen, (0, 0))
    else:
        # Fallback: Resim yüklenemezse basit ekran
        game.screen.fill(PINK)
        
        letter_text = game.font.render("Sevgili Nida...", True, RED)
        game.screen.blit(letter_text, (SCREEN_WIDTH // 2 - letter_text.get_width() // 2, 200))
    
    # Ana Menü butonu (sol alt köşe)
    menu_button_rect = pygame.Rect(20, SCREEN_HEIGHT - 60, 150, 40)
    pygame.draw.rect(game.screen, (100, 50, 50), menu_button_rect)
    pygame.draw.rect(game.screen, (200, 100, 100), menu_button_rect, 3)
    
    menu_text = game.small_font.render("Ana Menü", True, WHITE)
    menu_text_x = menu_button_rect.centerx - menu_text.get_width() // 2
    menu_text_y = menu_button_rect.centery - menu_text.get_height() // 2
    game.screen.blit(menu_text, (menu_text_x, menu_text_y))

def draw_game_over(game):
    """Oyun bitti ekranı - basaramadin.png göster"""
    if game.gameover_screen:
        game.screen.blit(game.gameover_screen, (0, 0))
    else:
        # Fallback: Resim yüklenemezse eski ekranı göster
        game.screen.fill((100, 100, 120))
        
        game_over_text = game.font.render("Kalbin kırıldı 💔", True, DARK_RED)
        game.screen.blit(game_over_text, (SCREEN_WIDTH // 2 - game_over_text.get_width() // 2, 200))
        
        score_text = game.font.render(f"Final Skor: {game.player.score}", True, WHITE)
        game.screen.blit(score_text, (SCREEN_WIDTH // 2 - score_text.get_width() // 2, 280))
        
        restart = game.small_font.render("R: Tekrar Oyna  |  M: Ana Menü", True, WHITE)
        game.screen.blit(restart, (SCREEN_WIDTH // 2 - restart.get_width() // 2, 400))


def draw_nida_b4(game):
    """Nida B4 ekranı - 3. bölüm sonrası, 4. bölüm öncesi"""
    if game.nida_b4_screen:
        game.screen.blit(game.nida_b4_screen, (0, 0))
    else:
        # Fallback: Resim yüklenemezse basit ekran
        game.screen.fill((50, 50, 80))
        
        text = game.font.render("Bölüm 4'e Hazır mısın?", True, PINK)
        game.screen.blit(text, (SCREEN_WIDTH // 2 - text.get_width() // 2, 250))
        
        continue_text = game.small_font.render("Enter/Space ile devam et", True, WHITE)
        game.screen.blit(continue_text, (SCREEN_WIDTH // 2 - continue_text.get_width() // 2, 350))
