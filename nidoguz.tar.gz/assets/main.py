"""
Web için ana giriş noktası
Pygbag bu dosyayı otomatik olarak çalıştırır
"""
import asyncio
import platform

# Web platformu kontrolü
if platform.system() == "Emscripten":
    print("🌐 Web platformunda çalışıyor!")
    import sys
    sys.path.insert(0, ".")

# Ana oyunu import et ve çalıştır
from valentine_game import Game

async def main():
    """Async ana fonksiyon - web için gerekli"""
    game = Game()
    
    # Oyun döngüsü
    while game.running:
        game.handle_events()
        game.update()
        game.draw()
        game.clock.tick(60)
        
        # Web için frame bekle
        await asyncio.sleep(0)
    
    import pygame
    pygame.quit()

# Oyunu başlat
if __name__ == "__main__":
    asyncio.run(main())
