# Vercel'e Deploy Etme Rehberi

## Yöntem 1: Vercel CLI (Önerilen)

### 1. Vercel CLI'yi Yükle
```bash
npm install -g vercel
```

### 2. Vercel'e Giriş Yap
```bash
vercel login
```

### 3. Deploy Et
```bash
vercel
```

İlk deploy'da sorular gelecek:
- Set up and deploy? → **Y**
- Which scope? → Hesabını seç
- Link to existing project? → **N**
- Project name? → **nidoguz** (veya istediğin isim)
- In which directory is your code located? → **./** (Enter)

### 4. Production'a Deploy
```bash
vercel --prod
```

---

## Yöntem 2: GitHub + Vercel (Otomatik)

### 1. GitHub'a Yükle
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/KULLANICI_ADIN/nidoguz.git
git push -u origin main
```

### 2. Vercel'e Bağla
1. https://vercel.com adresine git
2. "New Project" tıkla
3. GitHub repo'sunu seç
4. "Deploy" tıkla

Vercel otomatik olarak:
- Her commit'te yeniden deploy eder
- Preview URL'ler oluşturur
- Production URL verir

---

## Yöntem 3: Manuel (Build/Web Klasörü)

### 1. Lokal'de Build Et
```bash
WEB_CALISTIR.bat
```

### 2. build/web Klasörünü Vercel'e Yükle
1. https://vercel.com/new adresine git
2. "Deploy" sekmesinde "Browse" tıkla
3. `build/web` klasörünü seç
4. "Deploy" tıkla

---

## Sorun Giderme

### Python Build Hatası
Vercel Python 3.9+ destekler. Eğer hata alırsan `runtime.txt` ekle:
```
python-3.11
```

### Pygbag Yükleme Hatası
`requirements.txt` dosyası zaten var, Vercel otomatik yükleyecek.

### Favicon Görünmüyor
Build sonrası `icon.png` otomatik olarak `favicon.png` olarak kopyalanıyor.

---

## Önemli Notlar

- İlk build 2-3 dakika sürebilir
- Vercel ücretsiz planı yeterli
- Her deploy'da yeni URL alırsın
- Custom domain ekleyebilirsin (Hostinger domain'ini bağlayabilirsin)

---

## Hızlı Deploy (Tek Komut)

```bash
vercel --prod
```

Bu komut her şeyi otomatik yapar!
