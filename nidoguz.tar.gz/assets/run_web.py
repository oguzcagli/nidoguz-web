#!/usr/bin/env python3
"""Web sunucusunu başlatır ve HTML'i otomatik düzeltir"""

import subprocess
import time
import os
import sys

print("🔨 Build ediliyor...")
result = subprocess.run([sys.executable, "-m", "pygbag", "--build", "web"], 
                       capture_output=True, text=True)
print(result.stdout)

if result.returncode != 0:
    print("❌ Build hatası!")
    print(result.stderr)
    sys.exit(1)

print("\n🔧 HTML düzeltiliyor...")
subprocess.run([sys.executable, "fix_html_simple.py"])

print("\n🚀 Sunucu başlatılıyor...")
print("📱 Tarayıcıda aç: http://localhost:8000")
print("⏹️  Durdurmak için Ctrl+C")
print("-" * 50)

# Sunucuyu başlat
try:
    subprocess.run([sys.executable, "-m", "http.server", "8000", 
                   "--directory", "web/build/web"])
except KeyboardInterrupt:
    print("\n\n✅ Sunucu durduruldu!")
