# Bölüm arka planları
import pygame
from constants import *

# Cache için global değişkenler
_background_cache = {}
_cache_initialized = False

def clear_cache():
    """Cache'i temizle - yeniden yükleme için"""
    global _background_cache, _cache_initialized
    _background_cache = {}
    _cache_initialized = False
    print("Cache temizlendi!")

def _create_level_1_background():
    """Bölüm 1: Otogar/Terminal - Bir kere oluştur"""
    surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
    
    # otogar.png varsa onu kullan
    try:
        bg = pygame.image.load("otogar.png").convert()
        bg = pygame.transform.scale(bg, (SCREEN_WIDTH, SCREEN_HEIGHT))
        surface.blit(bg, (0, 0))
        print("✓ otogar.png başarıyla yüklendi ve kullanılıyor!")
        return surface
    except Exception as e:
        print(f"✗ otogar.png yüklenemedi: {e}")
        print("→ Çizili otogar kullanılıyor...")
    
    # Fallback: Çizili otogar
    surface.fill((135, 206, 250))
    
    # Otogar binası
    pygame.draw.rect(surface, (180, 180, 180), (50, 100, 700, 200))
    pygame.draw.rect(surface, (150, 150, 150), (50, 100, 700, 200), 3)
    
    # Çatı
    pygame.draw.polygon(surface, (200, 50, 50), [(30, 100), (400, 50), (770, 100)])
    
    # Pencereler
    for i in range(8):
        x = 100 + i * 80
        pygame.draw.rect(surface, (100, 150, 200), (x, 130, 50, 60))
        pygame.draw.rect(surface, (80, 120, 160), (x, 130, 50, 60), 2)
        pygame.draw.rect(surface, (100, 150, 200), (x, 220, 50, 60))
        pygame.draw.rect(surface, (80, 120, 160), (x, 220, 50, 60), 2)
    
    # Giriş kapısı
    pygame.draw.rect(surface, (139, 69, 19), (360, 240, 80, 60))
    pygame.draw.rect(surface, (101, 67, 33), (360, 240, 80, 60), 3)
    
    # "OTOGAR" yazısı
    font = pygame.font.Font(None, 48)
    text = font.render("OTOGAR", True, WHITE)
    text_bg = pygame.Surface((text.get_width() + 20, text.get_height() + 10))
    text_bg.fill((200, 50, 50))
    surface.blit(text_bg, (320, 60))
    surface.blit(text, (330, 65))
    
    # Otobüs (BÜYÜK)
    pygame.draw.rect(surface, (255, 200, 0), (550, 300, 220, 120))
    pygame.draw.rect(surface, (200, 150, 0), (550, 300, 220, 120), 4)
    
    for i in range(4):
        pygame.draw.rect(surface, (150, 200, 255), (570 + i * 50, 315, 40, 35))
        pygame.draw.rect(surface, (100, 150, 200), (570 + i * 50, 315, 40, 35), 2)
    
    pygame.draw.polygon(surface, (150, 200, 255), [(750, 315), (765, 315), (765, 345), (750, 350)])
    
    pygame.draw.circle(surface, BLACK, (600, 420), 22)
    pygame.draw.circle(surface, (80, 80, 80), (600, 420), 16)
    pygame.draw.circle(surface, BLACK, (720, 420), 22)
    pygame.draw.circle(surface, (80, 80, 80), (720, 420), 16)
    
    for i in range(10):
        pygame.draw.rect(surface, WHITE, (i * 80, 470, 40, 5))
    
    return surface

def _create_level_2_background():
    """Bölüm 2: Park"""
    surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
    
    # otobusici.png varsa onu kullan
    try:
        bg = pygame.image.load("otobusici.png").convert()
        bg = pygame.transform.scale(bg, (SCREEN_WIDTH, SCREEN_HEIGHT))
        surface.blit(bg, (0, 0))
        print("✓ otobusici.png başarıyla yüklendi ve kullanılıyor!")
        return surface
    except Exception as e:
        print(f"✗ otobusici.png yüklenemedi: {e}")
        print("→ Çizili park kullanılıyor...")
    
    # Fallback: Çizili park
    surface.fill((135, 206, 250))
    
    # Bulutlar
    for x in [100, 300, 500, 650]:
        pygame.draw.circle(surface, WHITE, (x, 80), 30)
        pygame.draw.circle(surface, WHITE, (x + 25, 80), 35)
        pygame.draw.circle(surface, WHITE, (x + 50, 80), 30)
    
    # Ağaçlar
    for x in [100, 250, 550, 700]:
        pygame.draw.rect(surface, (101, 67, 33), (x, 200, 30, 100))
        pygame.draw.circle(surface, (34, 139, 34), (x + 15, 180), 40)
        pygame.draw.circle(surface, (34, 139, 34), (x - 10, 200), 35)
        pygame.draw.circle(surface, (34, 139, 34), (x + 40, 200), 35)
    
    # Çimenler
    for i in range(20):
        x = i * 40
        for j in range(3):
            y = 350 + j * 30
            pygame.draw.line(surface, (50, 200, 50), (x, y), (x + 5, y - 10), 2)
    
    return surface

def _create_level_3_background():
    """Bölüm 3: Şehir"""
    surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
    
    # bolumucarkaplan.png varsa onu kullan
    try:
        bg = pygame.image.load("bolumucarkaplan.png").convert()
        bg = pygame.transform.scale(bg, (SCREEN_WIDTH, SCREEN_HEIGHT))
        surface.blit(bg, (0, 0))
        print("✓ bolumucarkaplan.png başarıyla yüklendi ve kullanılıyor!")
        return surface
    except Exception as e:
        print(f"✗ bolumucarkaplan.png yüklenemedi: {e}")
        print("→ Çizili şehir kullanılıyor...")
    
    # Fallback: Çizili şehir
    surface.fill((255, 140, 100))
    
    buildings = [(50, 150, 80, 200), (140, 100, 100, 250), (250, 180, 70, 170),
                 (330, 120, 90, 230), (430, 160, 80, 190), (520, 90, 110, 260), (640, 140, 90, 210)]
    
    for building in buildings:
        pygame.draw.rect(surface, (50, 50, 80), building)
        pygame.draw.rect(surface, (30, 30, 60), building, 2)
        x, y, w, h = building
        for i in range(3):
            for j in range(int(h / 30)):
                if (i + j) % 2 == 0:
                    pygame.draw.rect(surface, (255, 255, 150), (x + 10 + i * 20, y + 10 + j * 30, 15, 20))
    
    return surface

def _create_level_4_background():
    """Bölüm 4: Romantik Gece"""
    surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
    
    # asiklarkoprusu.png varsa onu kullan
    try:
        bg = pygame.image.load("asiklarkoprusu.png").convert()
        bg = pygame.transform.scale(bg, (SCREEN_WIDTH, SCREEN_HEIGHT))
        surface.blit(bg, (0, 0))
        print("✓ asiklarkoprusu.png başarıyla yüklendi ve kullanılıyor!")
        return surface
    except Exception as e:
        print(f"✗ asiklarkoprusu.png yüklenemedi: {e}")
        print("→ Çizili romantik gece kullanılıyor...")
    
    # Fallback: Çizili romantik gece
    surface.fill((25, 25, 60))
    
    import random
    random.seed(42)
    for _ in range(50):
        x = random.randint(0, SCREEN_WIDTH)
        y = random.randint(0, 300)
        size = random.randint(1, 3)
        pygame.draw.circle(surface, (255, 255, 200), (x, y), size)
    
    pygame.draw.circle(surface, (255, 255, 200), (650, 100), 40)
    pygame.draw.circle(surface, (25, 25, 60), (665, 95), 35)
    
    heart_positions = [(150, 120), (400, 80), (600, 150)]
    for hx, hy in heart_positions:
        pygame.draw.circle(surface, (255, 100, 150), (hx, hy), 12)
        pygame.draw.circle(surface, (255, 100, 150), (hx + 15, hy), 12)
        points = [(hx - 8, hy + 8), (hx + 7, hy + 25), (hx + 23, hy + 8)]
        pygame.draw.polygon(surface, (255, 100, 150), points)
    
    return surface

def init_backgrounds():
    """Arka planları bir kere oluştur (optimizasyon)"""
    global _background_cache, _cache_initialized
    # Cache'i temizle ve yeniden yükle
    clear_cache()
    _background_cache[0] = _create_level_1_background()
    _background_cache[1] = _create_level_2_background()
    _background_cache[2] = _create_level_3_background()
    _background_cache[3] = _create_level_4_background()
    _cache_initialized = True
    print("Arka planlar yüklendi!")

def draw_level_background(screen, level_index):
    """Cache'lenmiş arka planı çiz (HIZLI)"""
    if not _cache_initialized:
        init_backgrounds()
    screen.blit(_background_cache[level_index], (0, 0))
