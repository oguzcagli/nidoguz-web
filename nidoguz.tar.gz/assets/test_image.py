import pygame
pygame.init()

try:
    img = pygame.image.load("otogar.png")
    print(f"✓ otogar.png başarıyla yüklendi!")
    print(f"  Boyut: {img.get_width()}x{img.get_height()}")
except Exception as e:
    print(f"✗ Hata: {e}")

try:
    img = pygame.image.load("narlica.png")
    print(f"✓ narlica.png başarıyla yüklendi!")
    print(f"  Boyut: {img.get_width()}x{img.get_height()}")
except Exception as e:
    print(f"✗ Hata: {e}")
