# 🚀 Web'e Deployment Rehberi

## Hızlı Test (Lokal)

### Yöntem 1: Python Sunucu (Önerilen)
```bash
python web_server.py
```
Tarayıcınızda otomatik açılacak: http://localhost:8000

### Yöntem 2: Basit HTTP Sunucu
```bash
python -m http.server 8000
```

### Yöntem 3: Pygbag (Tam Özellikli)
```bash
pip install pygbag
pygbag valentine_game.py
```

## 🌐 Ücretsiz Hosting Seçenekleri

### 1. GitHub Pages (Önerilen - Ücretsiz)

**Adımlar:**
1. GitHub'da yeni repository oluştur
2. Tüm dosyaları push et:
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/KULLANICI_ADI/REPO_ADI.git
git push -u origin main
```

3. Repository Settings > Pages:
   - Source: Deploy from a branch
   - Branch: main
   - Folder: / (root)
   - Save

4. 2-3 dakika sonra oyun hazır:
   `https://KULLANICI_ADI.github.io/REPO_ADI/`

**index.html veya index_advanced.html?**
- `index.html` → Basit, hızlı yüklenir
- `index_advanced.html` → Daha güzel, kontroller gösterir

GitHub Pages için `index.html` kullanın veya `index_advanced.html`'i `index.html` olarak yeniden adlandırın.

---

### 2. Netlify (Çok Kolay - Ücretsiz)

**Adımlar:**
1. https://netlify.com adresine git
2. "Add new site" > "Deploy manually"
3. Tüm dosyaları sürükle-bırak
4. Deploy!

**Veya Git ile:**
1. GitHub'a push et
2. Netlify'da "Import from Git"
3. Repository'yi seç
4. Build settings:
   - Build command: (boş bırak)
   - Publish directory: `/`
5. Deploy!

Otomatik URL: `https://RANDOM-NAME.netlify.app`

---

### 3. Vercel (Hızlı - Ücretsiz)

**Adımlar:**
1. https://vercel.com adresine git
2. "New Project"
3. GitHub repository'yi import et
4. Deploy!

Otomatik URL: `https://PROJE-ADI.vercel.app`

---

### 4. Cloudflare Pages (Hızlı CDN - Ücretsiz)

**Adımlar:**
1. https://pages.cloudflare.com adresine git
2. "Create a project"
3. GitHub'ı bağla
4. Repository'yi seç
5. Build settings:
   - Build command: (boş)
   - Build output directory: `/`
6. Deploy!

---

### 5. Render (Ücretsiz)

**Adımlar:**
1. https://render.com adresine git
2. "New Static Site"
3. GitHub'ı bağla
4. Build command: (boş)
5. Publish directory: `.`
6. Deploy!

---

## 📦 Dosya Yapısı (Deployment için)

```
.
├── index.html              # Ana sayfa (basit)
├── index_advanced.html     # Gelişmiş sayfa
├── main.py                 # Web giriş noktası
├── valentine_game.py       # Ana oyun
├── constants.py
├── entities.py
├── levels.py
├── game_screens.py
├── backgrounds.py
├── requirements.txt
└── *.png                   # Tüm görseller
```

**Önemli:** Tüm `.png` dosyalarının root dizinde olması gerekiyor!

---

## 🔧 Sorun Giderme

### Oyun yüklenmiyor
- Tarayıcı konsolunu kontrol et (F12)
- CORS hatası varsa lokal sunucu kullan
- Tüm dosyaların yüklendiğinden emin ol

### Görseller görünmüyor
- Tüm `.png` dosyalarının aynı dizinde olduğunu kontrol et
- Dosya isimlerinin küçük harf olduğunu kontrol et
- Tarayıcı cache'ini temizle (Ctrl+Shift+R)

### Performans sorunları
- `constants.py`'de FPS'i düşür (30'a)
- Görselleri optimize et (boyutları küçült)
- Basit `index.html` kullan

### Mobil cihazda çalışmıyor
- Pygbag otomatik dokunmatik kontrol ekler
- Tarayıcı WebAssembly desteklemiyorsa çalışmaz
- Chrome/Safari kullan

---

## 🎨 Özelleştirme

### Başlık değiştir
`index.html` veya `index_advanced.html` içinde:
```html
<title>Yeni Başlık</title>
<h1>Yeni Başlık</h1>
```

### Renkler değiştir
CSS'deki `background` ve `color` değerlerini düzenle

### Boyut değiştir
```javascript
width: 800,  // Yeni genişlik
height: 600, // Yeni yükseklik
```

---

## 📊 Performans İpuçları

1. **Görselleri optimize et:**
   - PNG'leri sıkıştır (TinyPNG, ImageOptim)
   - Gereksiz görselleri kaldır

2. **FPS'i ayarla:**
   - Desktop: 60 FPS
   - Web: 30-45 FPS (daha iyi performans)

3. **Cache kullan:**
   - `backgrounds.py` zaten cache kullanıyor ✓

4. **CDN kullan:**
   - GitHub Pages, Netlify, Cloudflare otomatik CDN sağlar

---

## 🔒 Güvenlik

- Tüm dosyalar statik (güvenli)
- Sunucu tarafı kod yok
- HTTPS otomatik (GitHub Pages, Netlify, vb.)

---

## 📱 Mobil Destek

Pygbag otomatik olarak:
- Dokunmatik kontroller ekler
- Ekran boyutuna göre ölçekler
- Yatay/dikey mod destekler

---

## 🎯 Önerilen Deployment

**En kolay:** Netlify (drag & drop)
**En hızlı:** GitHub Pages (git push)
**En profesyonel:** Vercel veya Cloudflare Pages

Hepsi ücretsiz ve HTTPS ile gelir! 🎉
